export const SUPABASE_URL = 'https://your-supabase-url.supabase.co';
export const SUPABASE_ANON_KEY = 'your-supabase-anon-key';
